package com.cts.hrms;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		System.out.println("Hello world");
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		Customer customer = (Customer) ctx.getBean("customer");
		System.out.println(customer);
	}

}
